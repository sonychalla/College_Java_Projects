import java.util.Scanner;

import com.app.Car;
import com.app.factory.CarFactory;
import com.app.factory.FcatoryProduct;

public class Test 
{

	public static void main(String[] args) 
	{
           Scanner s=new Scanner(System.in);
           System.out.println("enter which type of vendor u want");;
           String vendor=s.nextLine();
           CarFactory carFactory=FcatoryProduct.getCarFactory(vendor);
           System.out.println("enter the car type");;
           String carType=s.nextLine();
           Car car=carFactory.getCar(carType);
           car.show();
           
	}

}
