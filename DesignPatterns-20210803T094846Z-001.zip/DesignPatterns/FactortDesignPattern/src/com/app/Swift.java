package com.app;

public class Swift implements Car
{
	public void show()
	{
		System.out.println("this is from swift");
	}

}
