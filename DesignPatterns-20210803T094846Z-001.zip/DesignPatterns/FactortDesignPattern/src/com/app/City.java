package com.app;

public class City implements Car {

	@Override
	public void show()
	{
		System.out.println("this is from city");

	}

}
