package com.app;

public class Brio implements Car {

	@Override
	public void show() 
	{
	System.out.println("this is from brio");

	}

}
