package com.app.factory;

public class FcatoryProduct 
{

	public static CarFactory getCarFactory(String vendor)
	{
		if(vendor.equals("maruthi"))
		{
			return new MaruthiFactory();
		}
		else
		{
		return new HondaCarFactory();
		}
	}
}
