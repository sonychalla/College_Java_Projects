package com.app.factory;

import com.app.Brio;
import com.app.Car;
import com.app.City;

public class HondaCarFactory implements CarFactory {

	@Override
	public Car getCar(String carType) 
	{
		
		if(carType.equals("brio"))
		{
			return new Brio();
		}
		else
		{
		return new City();
		}
	}

}
