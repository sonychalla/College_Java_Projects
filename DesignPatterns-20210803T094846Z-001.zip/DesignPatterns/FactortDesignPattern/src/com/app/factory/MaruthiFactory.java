package com.app.factory;

import com.app.Car;
import com.app.Dziro;
import com.app.Swift;

public class MaruthiFactory implements CarFactory 
{

	@Override
	public Car getCar(String carType)
	{
		if(carType.equals("swift"))
		{
			return new Swift();
		}
		else
		{
		return new  Dziro(); 
		}
	}

}
