
package com.app.factory;

import com.app.Car;

public interface CarFactory
{
	public Car getCar(String carType);

}
