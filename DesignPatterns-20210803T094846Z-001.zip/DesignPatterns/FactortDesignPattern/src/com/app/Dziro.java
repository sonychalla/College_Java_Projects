/**
 * 
 */
package com.app;

/**
 * @author monica
 *
 */
public class Dziro implements Car {

	/* (non-Javadoc)
	 * @see com.app.Car#show()
	 */
	@Override
	public void show() 
	{
	System.out.println("this is from dziro");

	}

}
