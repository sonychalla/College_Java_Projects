+package com.app;

public interface Car
{
	public void show();

}
