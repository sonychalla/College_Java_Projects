package com.app;

public class Test {

	public static void main(String[] args)
	{
	Singleton s=Singleton.getInstance();
	
	Singleton s1=Singleton.getInstance();
	
	
	Singleton s4=new Singleton(2);

	System.out.println(s4);
	}

}
