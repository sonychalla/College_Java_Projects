package com.app;

public class Singleton implements Cloneable
{
	private static Singleton singleton;
	 private Singleton()
	 {
		 
	 }
	 public static Singleton getInstance()
	 {
		 if(singleton!=null)
		 {
			 System.out.println("returned same object");
		      return singleton;
		 }
		 else
		 {
			 System.out.println("object created newly");
			 singleton=new Singleton();
			 return singleton;
		 }
		 
	 }
	 private Singleton(int i)
	 {
		 
	 }
	 public Object clone()
	 {
		 return new CloneNotSupportedException();
		 
	 }

}
