package fyuf;

public class vbxsf {

	public static void main(String[] args) 
	{
		vyhv df=new stjk();
		df.get();

	}

}
