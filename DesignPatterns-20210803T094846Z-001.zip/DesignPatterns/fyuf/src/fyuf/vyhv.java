package fyuf;

public class vyhv 
{
	public static void get()
	{
		System.out.println("this is from super class");
		
	}
	

}

