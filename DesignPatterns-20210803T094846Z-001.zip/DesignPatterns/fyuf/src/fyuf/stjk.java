package fyuf;

public class stjk extends vyhv
{
	public static void get()
	{
		System.out.println("this is from sub class");
		
	}

	

}
